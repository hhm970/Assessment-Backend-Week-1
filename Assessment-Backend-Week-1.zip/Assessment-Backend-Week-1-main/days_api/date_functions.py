"""Functions for working with dates."""

from datetime import datetime


def convert_to_datetime(date: str) -> datetime:
    pass


def get_days_between(first: datetime, last: datetime) -> int:
    pass


def get_day_of_week_on(date: datetime) -> str:
    pass
